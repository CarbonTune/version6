<?php
    header("Refresh: 300");
	require_once('config/appconfig.php');
	if (GUEST_REQUESTS_ENABLE == 'false' ) header("Location: blocked.php");
?>

<!DOCTYPE HTML>
<html>
    <head>
        <title>Request Service | FC Carbon</title>
    
    <style>
        body, html {width: 100%; height: 100%; margin: 0; padding: 0}
        .row-container {display: flex; width: 100%; height: 100%; flex-direction: column; background-color: blue; overflow: hidden;}
        .first-row {background-color: lime; }
        .second-row { flex-grow: 1; border: none; margin: 0; padding: 0; }
        
        #force-mobile {
            margin: 0 auto;
            border-style: none;
            border-color: inherit;
            border-width: 0px;
            -webkit-transform: scale(1.1);
            -webkit-transform-origin: 0 0;
            display: block;
        }



    </style>
    </head>
    
    
    <body>
        <iframe src="https://festify.us/party/-Liok9Sbts2KOoU8YuI4" id="force-mobile" class="second-row" width="50%" height="1375"></iframe>
    </body>
    
</html>
<!DOCTYPE HTML>
<html>
  <head>
    <title>FestifyController Carbon</title>
    <link rel="stylesheet" href="css/splash-home.css" />
  </head>
  <body>
    <div id="wrap">
      <!-- Header Block -->
      <div id="head">
        <h1 id="system_logo">
          <a href="www.ygco.ca/aboutfc">FestifyController Carbon</a>
        </h1>
        <br>
        <h2 id="product_logo">Welcome to FestifyController</h2>
        <h3 id="product_byline">Music democracy, amplified.</h3>
      </div>
      <br>
      <!-- Page Content Block -->
      <div id="page_content">
        <p>
            Your party is using FestifyController to make the playlist democratic. You choose what the party listens to, add songs, vote and listen.
            Learn more about FestifyController and use it at your next party. 
        </p>
        <br>
        <center>
            <a href="https://ygco.ca/aboutfc" target="_self" class="lrgbutton">About FestifyController.</a>
        </center>

      </div>
      <br><br><br><br>
      <div id="footer">
        <p>
          Copyright &copy; 2019 Nathan Dick. All Rights Reserved.
        </p>
      </div>
      
    </div>
  </body>  
</html>
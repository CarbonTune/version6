<?php
    /**
     * Don't edit the PHP or HTML code on this page. The rules for song requests can be changed to suit your event's needs.
     * These are contained in <li></li> tags. See the documentation for how to change, add or remove code for rules.
     * Provided you don't change it, these rules will display to all guests when they use the requests system on personal,
     * mobile devices.
     * 
     * FestifyController Carbon - Copyright (C) 2019 Nathan Dick. All Rights Reserved.
     */
    header("Refresh: 300");
    require_once('config/appconfig.php');
	if (GUEST_REQUESTS_ENABLE == 'false') {
	    
	    header("Location: blocked.php");
	    
	}
?>

<!DOCTYPE HTML>
<html>
    <head>
        <title>FestifyController Carbon</title>
        <link rel="stylesheet" href="css/continue-php.css" />
    </head>
    <body>
        <div class="grid-container">
            <div class="Splash-Content">
                <!-- <center> -->
                <h2>Song Requests - How it works:</h2>
                <ul>
                    <li>Search for your song, tap the "+" to add or "&hearts;" to move it closer to the top of the list.</li>
                    <li>All songs must be 8 minutes long or shorter.</li>
                    <li>The hosts ask all guests to limit requests to <strong>3 per hour</strong> to avoid flooding the queue.</li>
                    <li>The hosts reserve the right to skip any song at any time.</li>
                </ul>
                <p>If that works, then tap Continue. </p>
                <a class="btn" href="./rqLoad.php" target="_self">Continue.</a><br><br>
                <!-- </center> -->
            </div>
            <div class="Header">
                <h1><?php echo constant("PARTY_TITLE"); ?></h1>
            </div>
            <div class="Footer">
                <p class="attrib">FestifyController 6.0.0 (Carbon)<br>
                Copyright &copy; 2019 Nathan Dick</p>
            </div>
        </div>
    </body>
</html>
<?php
	require_once('./config/appconfig.php');
	if (ALLOW_CLOSURE_OVERRIDES == false ) header("Location: ovrblocked.php");
?>

<!DOCTYPE HTML>
<html>
    <head>
        <title>FestifyController Carbon</title>
        <link rel="stylesheet" href="https://static.ygco.ca/994/songweb-sr.css" />
    </head>
    <body style="background-color: red;">
        <div class="grid-container">
            <div class="Splash-Content">
                <h2>Request Service<br>Resident Override</h2>
                
                <p>This page is for authorized users only.</p>
                <a class="btn" href="rqResLoad.php" target="_self">Continue.</a><br><br>
            </div>
            <div class="Header">
                <h1>FestifyController Carbon</h1>
            </div>
            <div class="Footer">
                <p class="attrib">FestifyController Carbon<br>
                Copyright &copy; 2019 Nathan Dick</p>
            </div>
</div>
    </body>
</html>
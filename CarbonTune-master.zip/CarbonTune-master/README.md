# CarbonTune
A super lightweight app designed to add control and additional interface options for Festify democratic music web-app. Allows Party Hosts to open and close song requests, and modifies the Festify TV mode to include additional information and customizations.

This app is in active development with more features in-progress.

## Get started
* This software requires Festify and a Spotify Premium account.
* FestifyController runs on any web server with PHP 5.2 or later.
* [See this Wiki article for more.](https://github.com/ndi8093/FestifyController/wiki/Getting-Started-with-FestifyController)

## Documentation
View the [documentation](https://github.com/ndi8093/FestifyController/wiki) for this app. Please note, it's a work in progress.

## Release Log
V6.1.0 (2020-03-10)
Made the request system more mobile friendly, implemented a mobile-only capability for requests.

V6.0.0 (2020-01-31)
Complete rewrite, implemented PHP controls and simplified the entire system.

### Credits
We are separate from Festify. Festify is not associated with, does not sponsor or otherwise endorse this software. 
Their app makes this one possible, check it out at https://festify.rocks

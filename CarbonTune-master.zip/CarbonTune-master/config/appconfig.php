<?php
/** FestifyController v6.0.0 (Carbon 00)
  * This is the configuration file for this app.
  * Edit this file with your own settings and save it.
  *
  * IMPORTANT: Edit and save this file in plain ASCII text
  * using a text editor like Visual Studio Code or Notepad++
  *
  * Please note that this app requires Festify, a third-party, 
  * browser-based service. Visit festify.rocks to learn more.
  * Festify does not endorse, sponsor or otherwise involved with this project.
  * All trademarks are property of their respective owners.
  *
  * Made by Nathan Dick - www.ygco.ca
  * Copyright (C) 2019 Nathan Dick. All Rights Reserved.
  *
  * Read the documentation for more on this file - https://www.ygco.ca/fcdocs
  *
  * ALL of these constants are required for the app to function as intended.
  */

/** Site Base URL
  * Include the http:// or https:// before the domain.
  * DO NOT INCLUDE A TRAILING SLASH
  */

 define('BASEURL', '');

 /** 
 * Festify Settings
 * See the documentation for info on how to find these links.
 * This app WILL NOT WORK without them.
 */

 define('PARTYCODE', '');
 define('TVMODE_URL', '');
 define('RQAREA_URL', '');
 
/**
 * Display Board Settings
 * Add messages to the display boards. See the documentation for more.
 */

 define('PARTY_TITLE', 'Welcome');
 define('PARTY_MESSAGE_TOPRIGHT', '');
 define('PARTY_MESSAGE_BOTTOMRIGHT', 'Enjoy the Party');

/** 
 * ControllerUI Song Request Link
 * Displays on the Queue Viewer screens
 * By default, it is set to https://example.com/song
 * If you changed the default location, you're using a short link or a different setup, enter it below.
 * This link is used by both the Mobile request UI and the Kiosk UI by default.
 * See the documentation for more information.
 */

 define('REQUEST_LINK', ''); 

/**
  * Enable/Disable Song Requests
  * Use this to turn song requests on or off.
  * Set to 'true' (on) by default. See documentation for more.
  */
 define('GUEST_REQUESTS_ENABLE', 'true');

/**
 * Allow Request System Overrides
 * Enable this to allow selected people (usually hosts) to continue to put songs into the queue even if requests are closed.
 * Works at all times, regardless of whether the main song requests area is enabled or disabled.
 * Set to 'true' (on) by default. See docuementation for more.
 */

  define('ALLOW_CLOSURE_OVERRIDES', 'true')


?>

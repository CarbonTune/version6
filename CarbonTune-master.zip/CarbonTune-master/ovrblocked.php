<?php
    header("Refresh: 300");	
	require_once('config/appconfig.php');
	if (GUEST_REQUESTS_ENABLE == 'true' ) header("Location: mobilerq.php");
?>

<!DOCTYPE HTML>
<html>
  <head>
    <title>FestifyController Carbon</title>
    <link rel="stylesheet" href="css/splash-home.css" />
  </head>
  <body>
    <div id="wrap">
      <!-- Header Block -->
      <div id="head">
        <h1 id="system_logo">
          <a href="www.ygco.ca/aboutfc">FestifyController Carbon</a>
        </h1>
        <br>
        <h2 id="product_logo">Welcome to FestifyController</h2>
        <h3 id="product_byline">Music democracy, amplified.</h3>
      </div>
      <br>
      <!-- Page Content Block -->
      <div id="page_content">
        <p>
            Request Service Host Overrides are currently disabled.
            See the host in charge of this service for more information.
        </p>
        <br>

      </div>
      <br><br><br><br>
      <div id="footer">
        <p>
          Powered by FestifyController Carbon<br>
          Copyright &copy; 2019 Nathan Dick. All Rights Reserved.
        </p>
      </div>
      
    </div>
  </body>  
</html>
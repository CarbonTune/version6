<?php
	include('./config/appconfig.php');
	include('Mobile_Detect.php');

	$detect = new Mobile_Detect;

	if (GUEST_REQUESTS_ENABLE == true) {
		if ($detect->isMobile()){
			header("Location: rqLoadMobile.php");
		}
		else {
			header("Location: needMobile.php");
		}
	}
	else {
		header("Location: blocked.php");
	}
	
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title>Working... | FC Carbon</title>
	</head>
</html>

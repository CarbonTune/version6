<?php 
/**
 * Display Board - Bootstrap Layout
 * Display works best on screens larger than 15 inches.
 * No real editable content here. All constants defined in appconfig.php
 * 
 * Made by Nathan Dick - www.ygco.ca
 * Copyright (C) 2019 Nathan Dick. All Rights Reserved.
 *
 * Read the documentation for more on this file - https://www.ygco.ca/fcdocs
 */
 
/** Automatically reload every 30 minutes */
header("Refresh: 1800");

/** Load Config Settings */
require_once("config/appconfig.php");

?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>FestifyController 6</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

  </head>
  <body class="regular" scroll="no">

    <div class="container-fluid">
	<div class="row">
		<div class="col-md-4">
			<h3 style="color: white;" class="text-left text-primary">
				<?php echo constant("PARTY_TITLE"); ?>
			</h3>
		</div>
		<div class="col-md-4">
		    <p style="text-align: center;"><!-- Top Centre Message box --></p>
		</div>
		<div class="col-md-4">
		    
			<p style="text-align: right;"><a id="modal-370547" href="#modal-container-370547" role="button text-right" class="btn" data-toggle="modal">Setup</a></p>
			
			<div class="modal fade" id="modal-container-370547" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="myModalLabel">
								Options
							</h5> 
							<button type="button" class="close" data-dismiss="modal">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body">
							<!--<script>
								window.location.replace('<?php echo constant("BASEURL")?>/admin.php');
							</script>-->
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">
								Close
							</button>
						</div>
					</div>
					
				</div>
				
			</div>
			
			<p class="text-right mono">
				<?php echo constant("PARTY_MESSAGE_TOPRIGHT"); ?>
			</p>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<iframe style="border: none;" class="queueFrame" src="<?php echo constant("TVMODE_URL"); ?>" width="100%">Iframe not working</iframe>
		</div>
	</div>
	<div class="row">
		<div class="col-md-6">
			<p class="footer">FestifyController 6.0.0 (Carbon) <br>
			Copyright &copy; 2019 Nathan Dick</p>
		</div>
		<div class="col-md-6">
			<p class="text-center" style="padding: 4px; background-color: white; color: black;">
			<?php 
			    if (GUEST_REQUESTS_ENABLE == 'true') {
			        echo "Song Requests now open &mdash; " . constant("REQUEST_LINK");
			    }
			    else {
			        echo constant("PARTY_MESSAGE_BOTTOMRIGHT");
			    }
			
			
			
			?>
			
			
			</p>
		</div>
	</div>
</div>

    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/scripts.js"></script>
  </body>
</html>